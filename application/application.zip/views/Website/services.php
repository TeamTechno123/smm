<?php include('include/header.php'); ?>

<section class="page-default">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="">Services</h1>          
      </div>
    </div>
  </div>
</section>

<section class="page-sec-two">
  <div class="container">
        <div class="row">
          <div class="col-md-3 text-center ">
            <div class="bg-green2 category"> <p class="text-center py-2">Instagram</p>
            </div>           
          </div>
           <div class="col-md-3 text-center ">
            <div class="bg-green2 category"> <p class="text-center py-2">Instagram</p>
            </div>           
          </div>
            <div class="col-md-3 text-center ">
            <div class="bg-green2 category"> <p class="text-center py-2">Instagram</p>
            </div>           
          </div>
           <div class="col-md-3 text-center ">
            <div class="bg-green2 category"> <p class="text-center py-2">Instagram</p>
            </div>           
          </div>
         <div class="col-md-12" id="m-scroll">
                <h4 class="text-center pb-3"> <i class="fas fa-box-open mr-2"></i> Instagram | Followers</h4>
                <table class="table table-striped">
                  <thead class="thead-dark bg-green">
                    <tr>
                      <th class="bg-green" scope="col"> <i class="fas fa-tasks mr-2"></i> ID</th>
                      <th class="bg-green" scope="col"><i class="fas fa-tasks mr-2"></i>  SERVICE</th>
                      <th class="bg-green" scope="col"><i class="far fa-chart-bar mr-2"></i>RATE</th>
                      <th class="bg-green" scope="col"><i class="fas fa-grip-lines mr-2"></i> DESCRIPTION</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row">1138</th>
                      <td>Real Brazilian Instagram Followers</td>
                      <td>$ 2.90</td>
                      <td><button type="button" class="btn btn-primary bg-green" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-grip-lines "></i></button></td>
                    </tr>   

                     <tr>
                      <th scope="row">1138</th>
                      <td>Real Brazilian Instagram Followers</td>
                      <td>$ 2.90</td>
                      <td><button type="button" class="btn btn-primary bg-green" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-grip-lines "></i></button></td>
                    </tr>   


                     <tr>
                      <th scope="row">1138</th>
                      <td>Real Brazilian Instagram Followers</td>
                      <td>$ 2.90</td>
                      <td><button type="button" class="btn btn-primary bg-green" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-grip-lines "></i></button></td>
                    </tr>                  
                   
                  </tbody>
                </table>
              </div>

              <div class="col-md-12" id="m-scroll">
                <h4 class="text-center pb-3"> <i class="fas fa-box-open mr-2"></i> Instagram | Followers</h4>
                <table class="table table-striped">
                  <thead class="thead-dark bg-green">
                    <tr>
                      <th class="bg-green" scope="col"> <i class="fas fa-tasks mr-2"></i> ID</th>
                      <th class="bg-green" scope="col"><i class="fas fa-tasks mr-2"></i>  SERVICE</th>
                      <th class="bg-green" scope="col"><i class="far fa-chart-bar mr-2"></i>RATE</th>
                      <th class="bg-green" scope="col"><i class="fas fa-grip-lines mr-2"></i> DESCRIPTION</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row">1138</th>
                      <td>Real Brazilian Instagram Followers</td>
                      <td>$ 2.90</td>
                      <td><button type="button" class="btn btn-primary bg-green" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-grip-lines "></i></button></td>
                    </tr>   

                     <tr>
                      <th scope="row">1138</th>
                      <td>Real Brazilian Instagram Followers</td>
                      <td>$ 2.90</td>
                      <td><button type="button" class="btn btn-primary bg-green" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-grip-lines "></i></button></td>
                    </tr>   


                     <tr>
                      <th scope="row">1138</th>
                      <td>Real Brazilian Instagram Followers</td>
                      <td>$ 2.90</td>
                      <td><button type="button" class="btn btn-primary bg-green" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-grip-lines "></i></button></td>
                    </tr>                  
                   
                  </tbody>
                </table>
              </div>

              <div class="col-md-12" id="m-scroll">
                <h4 class="text-center pb-3"> <i class="fas fa-box-open mr-2"></i> Instagram | Followers</h4>
                <table class="table table-striped">
                  <thead class="thead-dark bg-green">
                    <tr>
                      <th class="bg-green" scope="col"> <i class="fas fa-tasks mr-2"></i> ID</th>
                      <th class="bg-green" scope="col"><i class="fas fa-tasks mr-2"></i>  SERVICE</th>
                      <th class="bg-green" scope="col"><i class="far fa-chart-bar mr-2"></i>RATE</th>
                      <th class="bg-green" scope="col"><i class="fas fa-grip-lines mr-2"></i> DESCRIPTION</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row">1138</th>
                      <td>Real Brazilian Instagram Followers</td>
                      <td>$ 2.90</td>
                      <td><button type="button" class="btn btn-primary bg-green" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-grip-lines "></i></button></td>
                    </tr>   

                     <tr>
                      <th scope="row">1138</th>
                      <td>Real Brazilian Instagram Followers</td>
                      <td>$ 2.90</td>
                      <td><button type="button" class="btn btn-primary bg-green" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-grip-lines "></i></button></td>
                    </tr>   


                     <tr>
                      <th scope="row">1138</th>
                      <td>Real Brazilian Instagram Followers</td>
                      <td>$ 2.90</td>
                      <td><button type="button" class="btn btn-primary bg-green" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-grip-lines "></i></button></td>
                    </tr>                  
                   
                  </tbody>
                </table>
              </div>
        </div> 
        </div>  
        
</section>


<!-- package description Modal -->

              <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Package One</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="description">
                  <p>Start Time: 0-15 minutes</p>
                  <p>Speed per Day: 5,000 - 10,000 Followers</p>
                  <p>No Refill/No Refund</p>
                  <p>aximum Order: 10,000</p>
                </div>
              </div>
              
            </div>
          </div>
        </div>

<?php include('include/footer.php'); ?>
