<div class="col-md-3 col-6">
  <a href="<?php echo base_url(); ?>Emp_Panel/Emp_Master/attendence_list">
    <div class="info-box">
      <span class="info-box-icon text-success"><i class="far fa-clock"></i></span>
      <div class="info-box-content">
        <span class="info-box-number text-primary f-14">Attendance</span>
         <span class="info-box-text text-secondary f-14">Attendance All</span>
      </div>
    </div>
  </a>
</div>
<div class="col-md-3 col-6">
<a href="<?php echo base_url(); ?>Emp_Panel/Emp_Master/employee">
  <div class="info-box">
    <span class="info-box-icon text-success"><i class="far fa-calendar-alt"></i></span>
    <div class="info-box-content">
      <span class="info-box-number text-primary f-14">Monthly Timesheet</span>
       <span class="info-box-text text-secondary f-14">View All</span>
    </div>
  </div>
</a>
</div>
<div class="col-md-3 col-6">
<a href="<?php echo base_url(); ?>Emp_Panel/Emp_Master/overtime_request">
<div class="info-box">
  <span class="info-box-icon text-success"><i class="far fa-clock"></i></span>
  <div class="info-box-content">
    <span class="info-box-number text-primary f-14">Overtime Request</span>
     <span class="info-box-text text-secondary f-14">Add Overtime Request</span>
  </div>
</div>
</a>
</div>
<div class="col-md-3 col-6">
<a href="<?php echo base_url(); ?>Emp_Panel/Emp_Master/leave">
<div class="info-box">
 <span class="info-box-icon text-danger"><i class="far fa-clock"></i></span>
 <div class="info-box-content">
   <span class="info-box-number text-primary f-14">Leave Request</span>
    <span class="info-box-text text-secondary f-14">Add Leave Request</span>
 </div>
</div>
</a>
</div>
