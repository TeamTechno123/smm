<div class="card card-widget widget-user-2">
  <div class="card-footer p-0">
    <ul class="nav flex-column hr_setting_leftmenu">
      <li class="nav-item ">
        <a href="<?php echo base_url(); ?>Emp_Panel/Emp_Profile/basic_info" class="nav-link ">Basic Information</a>
      </li>
       <li class="nav-item">
        <a href="<?php echo base_url(); ?>Emp_Panel/Emp_Profile/salary" class="nav-link">Salary</a>
      </li>
       <li class="nav-item">
        <a href="<?php echo base_url(); ?>Emp_Panel/Emp_Profile/employee_contact" class="nav-link">Emergency Number</a>
      </li>
       <li class="nav-item">
        <a href="<?php echo base_url(); ?>Emp_Panel/Emp_Profile/social" class="nav-link">Social Networking</a>
      </li>
       <li class="nav-item">
        <a href="<?php echo base_url(); ?>Emp_Panel/Emp_Profile/employee_doc" class="nav-link">Documents</a>
      </li>
       <li class="nav-item">
        <a href="<?php echo base_url(); ?>Emp_Panel/Emp_Profile/employee_edu" class="nav-link">Qualification</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Emp_Panel/Emp_Profile/employee_experience" class="nav-link">Work Experience</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Emp_Panel/Emp_Profile/employee_bank" class="nav-link">Bank Account</a>
      </li>

       <li class="nav-item">
        <a href="<?php echo base_url(); ?>Emp_Panel/Emp_Profile/change_password" class="nav-link">Change Password</a>
      </li>


    </ul>
  </div>
</div>
