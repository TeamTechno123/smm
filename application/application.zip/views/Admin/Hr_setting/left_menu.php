<div class="card card-widget widget-user-2">
  <div class="card-footer p-0">
    <ul class="nav flex-column hr_setting_leftmenu">
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/award_type" class="nav-link <?php if($setting_menu == 'award_type'){ echo 'active'; } ?>">Award Type</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/company_type" class="nav-link <?php if($setting_menu == 'company_type'){ echo 'active'; } ?>">Company Type</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/document_type" class="nav-link <?php if($setting_menu == 'document_type'){ echo 'active'; } ?>">Document Type</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/education_info" class="nav-link <?php if($setting_menu == 'education_info'){ echo 'active'; } ?>">Education Information</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/expense_type" class="nav-link <?php if($setting_menu == 'expense_type'){ echo 'active'; } ?>">Expense Type</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/contract_info" class="nav-link <?php if($setting_menu == 'contract_info'){ echo 'active'; } ?>">Contract Information</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/employee_exit_type" class="nav-link <?php if($setting_menu == 'employee_exit_type'){ echo 'active'; } ?>">Employee Exit Type</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/income_type" class="nav-link <?php if($setting_menu == 'income_type'){ echo 'active'; } ?>">Income Type</a>
      </li>
      <!-- <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/job_category" class="nav-link <?php if($setting_menu == 'job_category'){ echo 'active'; } ?>">Job Category</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/job_type" class="nav-link <?php if($setting_menu == 'job_type'){ echo 'active'; } ?>">Job Type</a>
      </li> -->
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/leave_type" class="nav-link <?php if($setting_menu == 'leave_type'){ echo 'active'; } ?>">Leave Type</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/religion_info" class="nav-link <?php if($setting_menu == 'religion_info'){ echo 'active'; } ?>">Religion Information</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/security_type" class="nav-link <?php if($setting_menu == 'security_type'){ echo 'active'; } ?>">Security Type</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/skill" class="nav-link <?php if($setting_menu == 'skill'){ echo 'active'; } ?>">Skill</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/termination_type" class="nav-link <?php if($setting_menu == 'termination_type'){ echo 'active'; } ?>">Termination Type</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/warning_type" class="nav-link <?php if($setting_menu == 'warning_type'){ echo 'active'; } ?>">Warning Type</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/travel_arr_type" class="nav-link <?php if($setting_menu == 'travel_arr_type'){ echo 'active'; } ?>">Travel Arrangement Type</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/language" class="nav-link <?php if($setting_menu == 'language'){ echo 'active'; } ?>">Language</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/currency" class="nav-link <?php if($setting_menu == 'currency'){ echo 'active'; } ?>">Currency</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/prof_course" class="nav-link <?php if($setting_menu == 'prof_course'){ echo 'active'; } ?>">Professional Course</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/nationality" class="nav-link <?php if($setting_menu == 'nationality'){ echo 'active'; } ?>">Nationality</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/citizenship" class="nav-link <?php if($setting_menu == 'citizenship'){ echo 'active'; } ?>">Citizenship</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo base_url(); ?>Hr_setting/payslip_type" class="nav-link <?php if($setting_menu == 'payslip_type'){ echo 'active'; } ?>">Payslip Type</a>
      </li>
    </ul>
  </div>
</div>
