<!DOCTYPE html>
<html>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-12 text-center mt-2">
            <h1> Dashboard Information</h1>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
      <div class="container-fluid">
        <hr>
        <h4 class="mb-3">Summary</h4>
        <div class="row">
          <div class="col-md-3 col-6">
            <div class="info-box">
              <span class="info-box-icon text-info"><i class="far fa-user"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-secondary">Company</span>
                <span class="info-box-number text-primary f-18">10</span>
              </div>
            </div>
          </div>
          <!-- <div class="col-md-3 col-6">
            <div class="info-box">
              <span class="info-box-icon text-info"><i class="far fa-money-bill-alt"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-secondary">Total Expenses</span>
                <span class="info-box-number text-primary f-18">20000</span>
              </div>
            </div>
          </div>
          <div class="col-md-3 col-6">
            <div class="info-box">
              <span class="info-box-icon text-info"><i class="far fa-calendar-alt"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-secondary">Total Expenses</span>
                <span class="info-box-number text-primary f-18">20000</span>
              </div>
            </div>
          </div>
          <div class="col-md-3 col-6">
            <div class="info-box">
              <span class="info-box-icon text-info"><i class="fas fa-calculator"></i></span>
              <div class="info-box-content">
                <span class="info-box-text text-secondary">Total Expenses</span>
                <span class="info-box-number text-primary f-18">20000</span>
              </div>
            </div>
          </div> -->











        </div>
        <hr>

      </div>
    </section>
  </div>


</body>
</html>
